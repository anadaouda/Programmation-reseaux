#ifndef CONSTANT_H_
#define CONSTANT_H_

#define MAX_BUFFER_SIZE 100
#define MAX_FD 20
#define MAX_USERNAME 50

#endif /* CONSTANT_H_ */
