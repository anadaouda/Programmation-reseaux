#ifndef CONSTANT_H_
#define CONSTANT_H_

#define MAX_BUFFER_SIZE 150
#define MAX_FD 20
#define MAX_USERNAME 50
#define MAX_CHANNEL_NAME 50

#endif /* CONSTANT_H_ */
